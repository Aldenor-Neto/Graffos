public class Aresta {

    public int origem;
    public int destino;

    Aresta(int origem, int destino) {
        this.origem = origem;
        this.destino = destino;
    }
}
